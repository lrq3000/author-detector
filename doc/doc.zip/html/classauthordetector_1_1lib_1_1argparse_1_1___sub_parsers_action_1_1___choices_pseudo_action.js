var classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action_1_1___choices_pseudo_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action_1_1___choices_pseudo_action.html#afccb738fdfecc0369436326d27b7b43a", null ]
];