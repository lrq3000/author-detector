var classauthordetector_1_1lib_1_1argparse_1_1___version_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___version_action.html#ab96737b58c1629a38097a4ff858d09d5", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1argparse_1_1___version_action.html#abb97f05e66b17ef613e2e12e66b07135", null ],
    [ "version", "classauthordetector_1_1lib_1_1argparse_1_1___version_action.html#a1449f527096ed0dd90cc980b91790e92", null ]
];