var classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1listviews_1_1_dict_column =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1listviews_1_1_dict_column.html#aa09bc22babe124bf2e23e324a0f793be", null ],
    [ "get", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1listviews_1_1_dict_column.html#a7ff22f7417194f25375a635bc944a18c", null ],
    [ "getter", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1listviews_1_1_dict_column.html#a2bc9a0a664c44e6ffaf90661ebe4ea05", null ]
];