var classauthordetector_1_1lib_1_1argparse_1_1_help_formatter =
[
    [ "_Section", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section.html", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section" ],
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html#ab683f83b8d22afb6e9aa597dc46d2b18", null ],
    [ "add_argument", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html#a4c90f309e7d585a11feaa2a5e6e6f664", null ],
    [ "add_arguments", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html#ae74755266df408e6a3af897986f1b9e6", null ],
    [ "add_text", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html#a1478771c699581e18930222ca01d6e9a", null ],
    [ "add_usage", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html#a734a92f34d0a67f8447290952d3fc0d2", null ],
    [ "end_section", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html#aa1d33ae551931f39dbf0006888ccc20e", null ],
    [ "format_help", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html#a3feecc66b9a9579395ea7eed6737fe59", null ],
    [ "start_section", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html#aed4cbd24437502808b3b004c5300170c", null ]
];