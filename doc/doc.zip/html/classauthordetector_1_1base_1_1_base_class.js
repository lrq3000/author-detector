var classauthordetector_1_1base_1_1_base_class =
[
    [ "__init__", "classauthordetector_1_1base_1_1_base_class.html#a4852af348aad6b167e11185583ebc5fb", null ],
    [ "loadconfig", "classauthordetector_1_1base_1_1_base_class.html#a70e80d3c7fc09a0ce4cbb3df5fa5eb95", null ],
    [ "config", "classauthordetector_1_1base_1_1_base_class.html#aea9607fb74ec956f8cfe040867dd45b7", null ],
    [ "parent", "classauthordetector_1_1base_1_1_base_class.html#af72696c98c4c6c114465316ed605e217", null ]
];