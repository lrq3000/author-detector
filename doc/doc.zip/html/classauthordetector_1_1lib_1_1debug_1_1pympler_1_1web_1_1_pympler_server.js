var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1web_1_1_pympler_server =
[
    [ "run", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1web_1_1_pympler_server.html#ab2b3c56d3fdb1fa2fd813f0a19fcca6f", null ],
    [ "server", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1web_1_1_pympler_server.html#a8049ad1a2c0809469ab4a914f11bd184", null ]
];