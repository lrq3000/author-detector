var classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_hot_shot_func_coverage =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_hot_shot_func_coverage.html#ab2d76581b3639ed7173038ca0da3938a", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_hot_shot_func_coverage.html#a100996cd0efa18396634c9f81f513e8d", null ],
    [ "atexit", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_hot_shot_func_coverage.html#a4fe255fd8f8cbfc4522ed659c49ccbae", null ],
    [ "fn", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_hot_shot_func_coverage.html#ac1880fb66ea6d5162415356824d55ef0", null ],
    [ "logfilename", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_hot_shot_func_coverage.html#ac147aa842b894d3ef7a3a4ed6509e53c", null ],
    [ "ncalls", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_hot_shot_func_coverage.html#a9cfb5c5c9cceea633d7d522d3cc40911", null ],
    [ "profiler", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_hot_shot_func_coverage.html#a8e46f1e3eba4167f4b4b35377dd8f081", null ]
];