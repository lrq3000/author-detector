var classauthordetector_1_1lib_1_1argparse_1_1___store_true_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___store_true_action.html#a4102b0b3a0035cfebf0093a5ccc19b4d", null ]
];