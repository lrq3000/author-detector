var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_console_browser =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_console_browser.html#aa2e608bed8c176236e4aa4e2c858ca29", null ],
    [ "stream", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_console_browser.html#ab5887b94fe730276341eb97f439eb1e3", null ]
];