var classauthordetector_1_1lib_1_1argparse_1_1___store_false_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___store_false_action.html#a6ad0f86c650f02523ab3f4d2dd863721", null ]
];