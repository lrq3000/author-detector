var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_t =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_t.html#af0690ff773cf212ba685f5e41c5785a5", null ],
    [ "a", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_t.html#aac39b43e75d065076209cc9e869e635e", null ],
    [ "b", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_t.html#a81634ac1d6820a2b6c50f53e7c1b5313", null ]
];