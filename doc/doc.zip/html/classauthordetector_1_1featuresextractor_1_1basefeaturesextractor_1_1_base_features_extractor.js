var classauthordetector_1_1featuresextractor_1_1basefeaturesextractor_1_1_base_features_extractor =
[
    [ "__init__", "classauthordetector_1_1featuresextractor_1_1basefeaturesextractor_1_1_base_features_extractor.html#a3b1068b59e0478e2d4453bd2cdc1a081", null ],
    [ "extract", "classauthordetector_1_1featuresextractor_1_1basefeaturesextractor_1_1_base_features_extractor.html#ac6e5c75ebace3e4dd56df4fcf41c3d0b", null ]
];