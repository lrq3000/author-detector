var classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_trace_func_coverage =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_trace_func_coverage.html#a06ebc1e9c4012ffb9fb26182af1a8325", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_trace_func_coverage.html#ae018f6f0f4a9baab78729e630d032603", null ],
    [ "atexit", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_trace_func_coverage.html#a0f6a42b669aebfea836570731f0653e4", null ],
    [ "fn", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_trace_func_coverage.html#aaeb24431f911987a0cdfb94dd54b9c68", null ],
    [ "logfilename", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_trace_func_coverage.html#a4625e30d2761e93ffc76b248e2c91ebb", null ],
    [ "ncalls", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_trace_func_coverage.html#a5ae61e365ee58bdf5d1608e12a07743c", null ]
];