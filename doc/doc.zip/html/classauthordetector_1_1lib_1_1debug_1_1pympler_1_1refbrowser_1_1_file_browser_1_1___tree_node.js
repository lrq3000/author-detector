var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_file_browser_1_1___tree_node =
[
    [ "drawtext", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_file_browser_1_1___tree_node.html#a43163be965f3d54924d3b83ab303e622", null ],
    [ "print_object", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_file_browser_1_1___tree_node.html#a5231363a16c02a4863b3c6931464be51", null ],
    [ "reload_referrers", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_file_browser_1_1___tree_node.html#a659b49f65bfe2aac518c0ae0a0824661", null ]
];