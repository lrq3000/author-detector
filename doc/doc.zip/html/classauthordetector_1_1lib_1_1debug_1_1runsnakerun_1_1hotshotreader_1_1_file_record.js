var classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1hotshotreader_1_1_file_record =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1hotshotreader_1_1_file_record.html#a519051bae2ebeb9adb1f86539f902576", null ],
    [ "filename", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1hotshotreader_1_1_file_record.html#ace725c4a23ca44fd1268bd5ceddbadee", null ],
    [ "fileno", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1hotshotreader_1_1_file_record.html#a8d9cdbf5f753b83cd9d8c5552cea08c4", null ],
    [ "functions", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1hotshotreader_1_1_file_record.html#aa4940876b12c9d70a361c6d021e06a20", null ]
];