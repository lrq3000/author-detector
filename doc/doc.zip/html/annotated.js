var annotated =
[
    [ "augmentedtermfrequency", "namespaceaugmentedtermfrequency.html", null ],
    [ "authordetector", null, [
      [ "base", null, [
        [ "BaseClass", "classauthordetector_1_1base_1_1_base_class.html", "classauthordetector_1_1base_1_1_base_class" ]
      ] ],
      [ "configparser", null, [
        [ "ConfigParser", "classauthordetector_1_1configparser_1_1_config_parser.html", "classauthordetector_1_1configparser_1_1_config_parser" ]
      ] ],
      [ "detector", null, [
        [ "basedetector", null, [
          [ "BaseDetector", "classauthordetector_1_1detector_1_1basedetector_1_1_base_detector.html", "classauthordetector_1_1detector_1_1basedetector_1_1_base_detector" ]
        ] ],
        [ "cosinesimilarity", null, [
          [ "CosineSimilarity", "classauthordetector_1_1detector_1_1cosinesimilarity_1_1_cosine_similarity.html", "classauthordetector_1_1detector_1_1cosinesimilarity_1_1_cosine_similarity" ]
        ] ],
        [ "simpleinference", null, [
          [ "SimpleInference", "classauthordetector_1_1detector_1_1simpleinference_1_1_simple_inference.html", "classauthordetector_1_1detector_1_1simpleinference_1_1_simple_inference" ]
        ] ]
      ] ],
      [ "featuresextractor", null, [
        [ "basefeaturesextractor", null, [
          [ "BaseFeaturesExtractor", "classauthordetector_1_1featuresextractor_1_1basefeaturesextractor_1_1_base_features_extractor.html", "classauthordetector_1_1featuresextractor_1_1basefeaturesextractor_1_1_base_features_extractor" ]
        ] ],
        [ "treetagger", null, [
          [ "TreeTagger", "classauthordetector_1_1featuresextractor_1_1treetagger_1_1_tree_tagger.html", "classauthordetector_1_1featuresextractor_1_1treetagger_1_1_tree_tagger" ]
        ] ]
      ] ],
      [ "interactive", "namespaceauthordetector_1_1interactive.html", null ],
      [ "lib", null, [
        [ "argparse", null, [
          [ "_AttributeHolder", "classauthordetector_1_1lib_1_1argparse_1_1___attribute_holder.html", "classauthordetector_1_1lib_1_1argparse_1_1___attribute_holder" ],
          [ "HelpFormatter", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter.html", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter" ],
          [ "RawDescriptionHelpFormatter", "classauthordetector_1_1lib_1_1argparse_1_1_raw_description_help_formatter.html", null ],
          [ "RawTextHelpFormatter", "classauthordetector_1_1lib_1_1argparse_1_1_raw_text_help_formatter.html", null ],
          [ "ArgumentDefaultsHelpFormatter", "classauthordetector_1_1lib_1_1argparse_1_1_argument_defaults_help_formatter.html", null ],
          [ "ArgumentError", "classauthordetector_1_1lib_1_1argparse_1_1_argument_error.html", "classauthordetector_1_1lib_1_1argparse_1_1_argument_error" ],
          [ "ArgumentTypeError", "classauthordetector_1_1lib_1_1argparse_1_1_argument_type_error.html", null ],
          [ "Action", "classauthordetector_1_1lib_1_1argparse_1_1_action.html", "classauthordetector_1_1lib_1_1argparse_1_1_action" ],
          [ "_StoreAction", "classauthordetector_1_1lib_1_1argparse_1_1___store_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___store_action" ],
          [ "_StoreConstAction", "classauthordetector_1_1lib_1_1argparse_1_1___store_const_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___store_const_action" ],
          [ "_StoreTrueAction", "classauthordetector_1_1lib_1_1argparse_1_1___store_true_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___store_true_action" ],
          [ "_StoreFalseAction", "classauthordetector_1_1lib_1_1argparse_1_1___store_false_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___store_false_action" ],
          [ "_AppendAction", "classauthordetector_1_1lib_1_1argparse_1_1___append_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___append_action" ],
          [ "_AppendConstAction", "classauthordetector_1_1lib_1_1argparse_1_1___append_const_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___append_const_action" ],
          [ "_CountAction", "classauthordetector_1_1lib_1_1argparse_1_1___count_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___count_action" ],
          [ "_HelpAction", "classauthordetector_1_1lib_1_1argparse_1_1___help_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___help_action" ],
          [ "_VersionAction", "classauthordetector_1_1lib_1_1argparse_1_1___version_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___version_action" ],
          [ "_SubParsersAction", "classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action" ],
          [ "FileType", "classauthordetector_1_1lib_1_1argparse_1_1_file_type.html", "classauthordetector_1_1lib_1_1argparse_1_1_file_type" ],
          [ "Namespace", "classauthordetector_1_1lib_1_1argparse_1_1_namespace.html", "classauthordetector_1_1lib_1_1argparse_1_1_namespace" ],
          [ "_ActionsContainer", "classauthordetector_1_1lib_1_1argparse_1_1___actions_container.html", "classauthordetector_1_1lib_1_1argparse_1_1___actions_container" ],
          [ "_ArgumentGroup", "classauthordetector_1_1lib_1_1argparse_1_1___argument_group.html", "classauthordetector_1_1lib_1_1argparse_1_1___argument_group" ],
          [ "_MutuallyExclusiveGroup", "classauthordetector_1_1lib_1_1argparse_1_1___mutually_exclusive_group.html", "classauthordetector_1_1lib_1_1argparse_1_1___mutually_exclusive_group" ],
          [ "ArgumentParser", "classauthordetector_1_1lib_1_1argparse_1_1_argument_parser.html", "classauthordetector_1_1lib_1_1argparse_1_1_argument_parser" ]
        ] ],
        [ "debug", null, [
          [ "kthread", "namespaceauthordetector_1_1lib_1_1debug_1_1kthread.html", "namespaceauthordetector_1_1lib_1_1debug_1_1kthread" ],
          [ "memory_profiler", "namespaceauthordetector_1_1lib_1_1debug_1_1memory__profiler.html", "namespaceauthordetector_1_1lib_1_1debug_1_1memory__profiler" ],
          [ "profilebrowser", null, [
            [ "ProfileBrowser", "classauthordetector_1_1lib_1_1debug_1_1profilebrowser_1_1_profile_browser.html", "classauthordetector_1_1lib_1_1debug_1_1profilebrowser_1_1_profile_browser" ]
          ] ],
          [ "profilehooks", "namespaceauthordetector_1_1lib_1_1debug_1_1profilehooks.html", "namespaceauthordetector_1_1lib_1_1debug_1_1profilehooks" ],
          [ "pycallgraph", null, [
            [ "PyCallGraphException", "classauthordetector_1_1lib_1_1debug_1_1pycallgraph_1_1_py_call_graph_exception.html", null ],
            [ "GlobbingFilter", "classauthordetector_1_1lib_1_1debug_1_1pycallgraph_1_1_globbing_filter.html", "classauthordetector_1_1lib_1_1debug_1_1pycallgraph_1_1_globbing_filter" ]
          ] ],
          [ "pympler", null, [
            [ "asizeof", null, [
              [ "_Claskey", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___claskey.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___claskey" ],
              [ "_NamedRef", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___named_ref.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___named_ref" ],
              [ "_Slots", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___slots.html", null ],
              [ "_Typedef", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___typedef.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___typedef" ],
              [ "_Prof", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___prof.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___prof" ],
              [ "Asized", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_asized.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_asized" ],
              [ "Asizer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_asizer.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_asizer" ],
              [ "C", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_c.html", null ],
              [ "D", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_d.html", null ],
              [ "E", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_e.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_e" ],
              [ "P", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_p.html", null ],
              [ "O", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_o.html", null ],
              [ "S", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_s.html", null ],
              [ "T", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_t.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_t" ],
              [ "_Dict", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___dict.html", null ],
              [ "Old", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_old.html", null ],
              [ "New", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_new.html", null ],
              [ "Sub", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_sub.html", null ]
            ] ],
            [ "charts", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1charts.html", null ],
            [ "classtracker", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1classtracker.html", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1classtracker" ],
            [ "classtracker_stats", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1classtracker__stats.html", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1classtracker__stats" ],
            [ "garbagegraph", null, [
              [ "GarbageGraph", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1garbagegraph_1_1_garbage_graph.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1garbagegraph_1_1_garbage_graph" ]
            ] ],
            [ "metadata", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1metadata.html", null ],
            [ "mprofile", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1mprofile.html", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1mprofile" ],
            [ "process", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1process.html", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1process" ],
            [ "refbrowser", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser.html", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser" ],
            [ "refgraph", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1refgraph.html", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1refgraph" ],
            [ "summary", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1summary.html", null ],
            [ "tracker", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1tracker.html", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1tracker" ],
            [ "util", null, [
              [ "bottle2", null, [
                [ "BottleException", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_bottle_exception.html", null ],
                [ "HTTPResponse", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_h_t_t_p_response.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_h_t_t_p_response" ],
                [ "HTTPError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_h_t_t_p_error.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_h_t_t_p_error" ],
                [ "RouteError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_route_error.html", null ],
                [ "RouteSyntaxError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_route_syntax_error.html", null ],
                [ "RouteBuildError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_route_build_error.html", null ],
                [ "Route", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_route.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_route" ],
                [ "Router", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_router.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_router" ],
                [ "Bottle", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_bottle.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_bottle" ],
                [ "Request", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_request.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_request" ],
                [ "Response", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_response.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_response" ],
                [ "MultiDict", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_multi_dict.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_multi_dict" ],
                [ "HeaderDict", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_header_dict.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_header_dict" ],
                [ "AppStack", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_app_stack.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_app_stack" ],
                [ "ServerAdapter", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_server_adapter.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_server_adapter" ],
                [ "CGIServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_c_g_i_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_c_g_i_server" ],
                [ "FlupFCGIServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_flup_f_c_g_i_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_flup_f_c_g_i_server" ],
                [ "WSGIRefServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_w_s_g_i_ref_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_w_s_g_i_ref_server" ],
                [ "CherryPyServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_cherry_py_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_cherry_py_server" ],
                [ "PasteServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_paste_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_paste_server" ],
                [ "FapwsServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_fapws_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_fapws_server" ],
                [ "TornadoServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_tornado_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_tornado_server" ],
                [ "AppEngineServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_app_engine_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_app_engine_server" ],
                [ "TwistedServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_twisted_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_twisted_server" ],
                [ "DieselServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_diesel_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_diesel_server" ],
                [ "GunicornServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_gunicorn_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_gunicorn_server" ],
                [ "AutoServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_auto_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_auto_server" ],
                [ "TemplateError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_template_error.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_template_error" ],
                [ "BaseTemplate", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_base_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_base_template" ],
                [ "MakoTemplate", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_mako_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_mako_template" ],
                [ "CheetahTemplate", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_cheetah_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_cheetah_template" ],
                [ "Jinja2Template", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_jinja2_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_jinja2_template" ],
                [ "SimpleTemplate", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_simple_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_simple_template" ]
              ] ],
              [ "bottle3", null, [
                [ "BottleException", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_bottle_exception.html", null ],
                [ "HTTPResponse", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_response.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_response" ],
                [ "HTTPError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_error.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_error" ],
                [ "RouteError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_route_error.html", null ],
                [ "RouteSyntaxError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_route_syntax_error.html", null ],
                [ "RouteBuildError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_route_build_error.html", null ],
                [ "Route", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_route.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_route" ],
                [ "Router", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_router.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_router" ],
                [ "Bottle", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_bottle.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_bottle" ],
                [ "Request", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_request.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_request" ],
                [ "Response", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_response.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_response" ],
                [ "MultiDict", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_multi_dict.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_multi_dict" ],
                [ "HeaderDict", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_header_dict.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_header_dict" ],
                [ "AppStack", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_app_stack.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_app_stack" ],
                [ "ServerAdapter", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_server_adapter.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_server_adapter" ],
                [ "CGIServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_c_g_i_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_c_g_i_server" ],
                [ "FlupFCGIServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_flup_f_c_g_i_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_flup_f_c_g_i_server" ],
                [ "WSGIRefServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_w_s_g_i_ref_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_w_s_g_i_ref_server" ],
                [ "CherryPyServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_cherry_py_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_cherry_py_server" ],
                [ "PasteServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_paste_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_paste_server" ],
                [ "FapwsServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_fapws_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_fapws_server" ],
                [ "TornadoServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_tornado_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_tornado_server" ],
                [ "AppEngineServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_app_engine_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_app_engine_server" ],
                [ "TwistedServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_twisted_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_twisted_server" ],
                [ "DieselServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_diesel_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_diesel_server" ],
                [ "GunicornServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_gunicorn_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_gunicorn_server" ],
                [ "AutoServer", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_auto_server.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_auto_server" ],
                [ "TemplateError", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_template_error.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_template_error" ],
                [ "BaseTemplate", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_base_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_base_template" ],
                [ "MakoTemplate", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_mako_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_mako_template" ],
                [ "CheetahTemplate", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_cheetah_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_cheetah_template" ],
                [ "Jinja2Template", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_jinja2_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_jinja2_template" ],
                [ "SimpleTemplate", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_simple_template.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_simple_template" ]
              ] ],
              [ "compat", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1compat.html", null ],
              [ "stringutils", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1stringutils.html", null ]
            ] ],
            [ "web", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1web.html", "namespaceauthordetector_1_1lib_1_1debug_1_1pympler_1_1web" ]
          ] ],
          [ "runsnakerun", "namespaceauthordetector_1_1lib_1_1debug_1_1runsnakerun.html", "namespaceauthordetector_1_1lib_1_1debug_1_1runsnakerun" ],
          [ "squaremap", "namespaceauthordetector_1_1lib_1_1debug_1_1squaremap.html", "namespaceauthordetector_1_1lib_1_1debug_1_1squaremap" ]
        ] ],
        [ "mp_guard", null, [
          [ "Brick", "classauthordetector_1_1lib_1_1mp__guard_1_1_brick.html", "classauthordetector_1_1lib_1_1mp__guard_1_1_brick" ]
        ] ],
        [ "treetagger", null, [
          [ "treetaggerwrapper", null, [
            [ "TreeTaggerError", "classauthordetector_1_1lib_1_1treetagger_1_1treetaggerwrapper_1_1_tree_tagger_error.html", null ],
            [ "TreeTagger", "classauthordetector_1_1lib_1_1treetagger_1_1treetaggerwrapper_1_1_tree_tagger.html", "classauthordetector_1_1lib_1_1treetagger_1_1treetaggerwrapper_1_1_tree_tagger" ]
          ] ]
        ] ]
      ] ],
      [ "merger", null, [
        [ "basemerger", null, [
          [ "BaseMerger", "classauthordetector_1_1merger_1_1basemerger_1_1_base_merger.html", "classauthordetector_1_1merger_1_1basemerger_1_1_base_merger" ]
        ] ],
        [ "countmerger", null, [
          [ "CountMerger", "classauthordetector_1_1merger_1_1countmerger_1_1_count_merger.html", "classauthordetector_1_1merger_1_1countmerger_1_1_count_merger" ]
        ] ]
      ] ],
      [ "patternsextractor", null, [
        [ "basepatternsextractor", null, [
          [ "BasePatternsExtractor", "classauthordetector_1_1patternsextractor_1_1basepatternsextractor_1_1_base_patterns_extractor.html", "classauthordetector_1_1patternsextractor_1_1basepatternsextractor_1_1_base_patterns_extractor" ]
        ] ],
        [ "ngrams", null, [
          [ "NGrams", "classauthordetector_1_1patternsextractor_1_1ngrams_1_1_n_grams.html", "classauthordetector_1_1patternsextractor_1_1ngrams_1_1_n_grams" ]
        ] ]
      ] ],
      [ "postprocessor", null, [
        [ "augmentedtermfrequency", null, [
          [ "AugmentedTermFrequency", "classauthordetector_1_1postprocessor_1_1augmentedtermfrequency_1_1_augmented_term_frequency.html", "classauthordetector_1_1postprocessor_1_1augmentedtermfrequency_1_1_augmented_term_frequency" ]
        ] ],
        [ "basepostprocessor", null, [
          [ "BasePostProcessor", "classauthordetector_1_1postprocessor_1_1basepostprocessor_1_1_base_post_processor.html", "classauthordetector_1_1postprocessor_1_1basepostprocessor_1_1_base_post_processor" ]
        ] ],
        [ "filterlowcount", null, [
          [ "FilterLowCount", "classauthordetector_1_1postprocessor_1_1filterlowcount_1_1_filter_low_count.html", "classauthordetector_1_1postprocessor_1_1filterlowcount_1_1_filter_low_count" ]
        ] ],
        [ "termfrequency", null, [
          [ "TermFrequency", "classauthordetector_1_1postprocessor_1_1termfrequency_1_1_term_frequency.html", "classauthordetector_1_1postprocessor_1_1termfrequency_1_1_term_frequency" ]
        ] ],
        [ "tfidf", null, [
          [ "TFIDF", "classauthordetector_1_1postprocessor_1_1tfidf_1_1_t_f_i_d_f.html", "classauthordetector_1_1postprocessor_1_1tfidf_1_1_t_f_i_d_f" ]
        ] ]
      ] ],
      [ "preprocessor", null, [
        [ "basepreprocessor", null, [
          [ "BasePreProcessor", "classauthordetector_1_1preprocessor_1_1basepreprocessor_1_1_base_pre_processor.html", "classauthordetector_1_1preprocessor_1_1basepreprocessor_1_1_base_pre_processor" ]
        ] ],
        [ "regexpfilter", null, [
          [ "RegexpFilter", "classauthordetector_1_1preprocessor_1_1regexpfilter_1_1_regexp_filter.html", "classauthordetector_1_1preprocessor_1_1regexpfilter_1_1_regexp_filter" ]
        ] ],
        [ "stopwordsfilter", null, [
          [ "StopWordsFilter", "classauthordetector_1_1preprocessor_1_1stopwordsfilter_1_1_stop_words_filter.html", "classauthordetector_1_1preprocessor_1_1stopwordsfilter_1_1_stop_words_filter" ]
        ] ],
        [ "xmlstripper", null, [
          [ "XMLStripper", "classauthordetector_1_1preprocessor_1_1xmlstripper_1_1_x_m_l_stripper.html", "classauthordetector_1_1preprocessor_1_1xmlstripper_1_1_x_m_l_stripper" ]
        ] ]
      ] ],
      [ "reader", null, [
        [ "basetextreader", null, [
          [ "BaseTextReader", "classauthordetector_1_1reader_1_1basetextreader_1_1_base_text_reader.html", "classauthordetector_1_1reader_1_1basetextreader_1_1_base_text_reader" ]
        ] ]
      ] ],
      [ "run", null, [
        [ "Runner", "classauthordetector_1_1run_1_1_runner.html", "classauthordetector_1_1run_1_1_runner" ]
      ] ],
      [ "validator", null, [
        [ "basevalidator", null, [
          [ "BaseValidator", "classauthordetector_1_1validator_1_1basevalidator_1_1_base_validator.html", "classauthordetector_1_1validator_1_1basevalidator_1_1_base_validator" ]
        ] ],
        [ "salience", null, [
          [ "Salience", "classauthordetector_1_1validator_1_1salience_1_1_salience.html", "classauthordetector_1_1validator_1_1salience_1_1_salience" ]
        ] ]
      ] ]
    ] ],
    [ "base", "namespacebase.html", null ],
    [ "basedetector", "namespacebasedetector.html", null ],
    [ "basefeaturesextractor", "namespacebasefeaturesextractor.html", null ],
    [ "basemerger", "namespacebasemerger.html", null ],
    [ "basepatternsextractor", "namespacebasepatternsextractor.html", null ],
    [ "basepostprocessor", "namespacebasepostprocessor.html", null ],
    [ "basepreprocessor", "namespacebasepreprocessor.html", null ],
    [ "basetextreader", "namespacebasetextreader.html", null ],
    [ "basevalidator", "namespacebasevalidator.html", null ],
    [ "cosinesimilarity", "namespacecosinesimilarity.html", null ],
    [ "countmerger", "namespacecountmerger.html", null ],
    [ "filterlowcount", "namespacefilterlowcount.html", null ],
    [ "ngrams", "namespacengrams.html", null ],
    [ "regexpfilter", "namespaceregexpfilter.html", null ],
    [ "salience", "namespacesalience.html", null ],
    [ "simpleinference", "namespacesimpleinference.html", null ],
    [ "stopwordsfilter", "namespacestopwordsfilter.html", "namespacestopwordsfilter" ],
    [ "termfrequency", "namespacetermfrequency.html", null ],
    [ "tfidf", "namespacetfidf.html", null ],
    [ "treetagger", "namespacetreetagger.html", null ],
    [ "xmlstripper", "namespacexmlstripper.html", null ]
];