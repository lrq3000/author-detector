var classauthordetector_1_1lib_1_1argparse_1_1___count_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___count_action.html#a34bbde8fcae59b53b8673c54214e6bba", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1argparse_1_1___count_action.html#ab21780d5b7015395db51f7ecc3fe5f26", null ]
];