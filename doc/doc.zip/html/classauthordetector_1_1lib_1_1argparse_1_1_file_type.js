var classauthordetector_1_1lib_1_1argparse_1_1_file_type =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1_file_type.html#adaa635f6f0c2ca09c415dbbb63fcd869", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1argparse_1_1_file_type.html#aa535a5ee6672d6870e4d920a7edf5a6d", null ],
    [ "__repr__", "classauthordetector_1_1lib_1_1argparse_1_1_file_type.html#af7961fc20625f5eaa774a8126f1d6417", null ]
];