var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_app_stack =
[
    [ "__call__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_app_stack.html#a6488662044b790e5fbe6406b0b3ace97", null ],
    [ "push", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle2_1_1_app_stack.html#a49c5931276e38e343210bfa2a5b5ff67", null ]
];