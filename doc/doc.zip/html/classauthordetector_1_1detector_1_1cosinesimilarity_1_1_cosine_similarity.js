var classauthordetector_1_1detector_1_1cosinesimilarity_1_1_cosine_similarity =
[
    [ "__init__", "classauthordetector_1_1detector_1_1cosinesimilarity_1_1_cosine_similarity.html#aecaa6228894db84d67db7a2e716ab252", null ],
    [ "detect", "classauthordetector_1_1detector_1_1cosinesimilarity_1_1_cosine_similarity.html#a0dc14ad80d86eb4e884bb2c043ba7d8a", null ]
];