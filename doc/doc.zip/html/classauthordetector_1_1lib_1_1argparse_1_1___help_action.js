var classauthordetector_1_1lib_1_1argparse_1_1___help_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___help_action.html#a9d17e8c2224632550cade1855916db7f", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1argparse_1_1___help_action.html#aa52c6fc06ca11a814060b4821ce341cb", null ]
];