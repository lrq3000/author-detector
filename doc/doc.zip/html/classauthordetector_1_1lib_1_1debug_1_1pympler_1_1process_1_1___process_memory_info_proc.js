var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc =
[
    [ "_ProcessMemoryInfoResource", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc_1_1___process_memory_info_resource.html", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc_1_1___process_memory_info_resource" ],
    [ "update", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc.html#a164c7886fff9c11d441ed7023f473989", null ],
    [ "code_segment", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc.html#a6506632864e14bc7494fc370f0f2a0a6", null ],
    [ "data_segment", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc.html#a497bfdd501dabe9a460f35ab5bf96850", null ],
    [ "pagefaults", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc.html#a94ba4c2c4dc5e83d2d95bf321d89cddc", null ],
    [ "rss", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc.html#ade522a7af874985ab3c547194f567b58", null ],
    [ "shared_segment", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc.html#a9d2fff4f11ecafcb7952fd6898608b05", null ],
    [ "stack_segment", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc.html#a6cd35018c9d9a0ea8022fbf7bcd7e933", null ],
    [ "vsz", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_proc.html#a2a3e602c17ea89d5b73e5523e18a6d72", null ]
];