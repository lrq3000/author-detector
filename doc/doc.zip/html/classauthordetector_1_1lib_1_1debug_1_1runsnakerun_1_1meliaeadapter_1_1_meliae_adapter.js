var classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter =
[
    [ "background_color", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter.html#a4bced5d17f81818efd755f84c7abf587", null ],
    [ "children", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter.html#a62949ef875a06ab97be1a9be28a28b96", null ],
    [ "empty", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter.html#ab1c6d4daa9e387320439207de1685064", null ],
    [ "filename", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter.html#ac37d4affc8720d8d4eca1de290ce6378", null ],
    [ "label", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter.html#a9f13525ccf20ee75e55ce6293fa32a43", null ],
    [ "overall", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter.html#a1f1e80642e2de60eb4d81bdac700b7c6", null ],
    [ "parents", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter.html#a89b3fb97f7a985817e7a799987ad893f", null ],
    [ "value", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_meliae_adapter.html#afe64e6043c8e152a640cbfeca21c2749", null ]
];