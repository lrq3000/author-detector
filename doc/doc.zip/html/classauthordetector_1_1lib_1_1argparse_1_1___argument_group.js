var classauthordetector_1_1lib_1_1argparse_1_1___argument_group =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___argument_group.html#ab65493db877297e0cdbb9ec472439541", null ],
    [ "title", "classauthordetector_1_1lib_1_1argparse_1_1___argument_group.html#a6f872d61c8a7b2df4a0a9c184ed232da", null ]
];