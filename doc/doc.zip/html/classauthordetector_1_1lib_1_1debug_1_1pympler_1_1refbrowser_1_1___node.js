var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1___node =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1___node.html#afab0db9ba9ef5ecfd69c773393aa2e40", null ],
    [ "__str__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1___node.html#a661ccdfa4327278157e120e5dd6c348b", null ],
    [ "children", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1___node.html#ac62bf43158a5e10dd7c88dd7824c25e7", null ],
    [ "o", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1___node.html#ad3da59317f8a13a199eaf54f186b7358", null ],
    [ "str_func", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1___node.html#a5ccd695e54dda3f10e6c69561edc4532", null ]
];