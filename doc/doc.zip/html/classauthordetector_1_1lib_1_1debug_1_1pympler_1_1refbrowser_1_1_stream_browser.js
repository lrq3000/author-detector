var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_stream_browser =
[
    [ "print_tree", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_stream_browser.html#a2adcc3897a2ba0c27984e1422406b830", null ]
];