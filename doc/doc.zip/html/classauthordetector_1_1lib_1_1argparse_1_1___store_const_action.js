var classauthordetector_1_1lib_1_1argparse_1_1___store_const_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___store_const_action.html#acfd05be0fc509d54f0a8071138fb974f", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1argparse_1_1___store_const_action.html#a60b63a97e83974f781dd4851cfc2eca1", null ]
];