var classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#aa72ec414151123ec92b6c0dccbca0ac9", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#a0a40a4186c21ed5cfdb155764d5d1db6", null ],
    [ "atexit", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#aab752a6786d4fa34c205f0dc111dbcbb", null ],
    [ "print_stats", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#a419a4c74fc59485f46d05c4084da6aa9", null ],
    [ "reset_stats", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#aab733beae5283481bba9c770fd2028ed", null ],
    [ "dirs", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#a56d42c5ea2d58111afdfc5f33a2c469b", null ],
    [ "entries", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#ac40e7bee525787b3a4c940d453d9f945", null ],
    [ "filename", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#a06995e3d33591cd17995295bf0354631", null ],
    [ "fn", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#a85f8e9d7bfe3b8166f837221c21183b9", null ],
    [ "immediate", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#ad61ef57c8d2a47f1cbddb30d91709a7a", null ],
    [ "ncalls", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#abb8d612a61be4899c1f90324835301b2", null ],
    [ "skip", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#ac69a99637ad4e5910111c3a9e1ace1e5", null ],
    [ "skipped", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#aeebf28d26ff2e9aa043a109ba90fd120", null ],
    [ "sort", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#aad9df44da42e8085fd98f596875e1026", null ],
    [ "stats", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_profile.html#a3ff55c6d085399dc27a17ff4ebc079e3", null ]
];