var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_app_stack =
[
    [ "__call__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_app_stack.html#aef6fbe43d79433a145fb5dc72647088b", null ],
    [ "push", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_app_stack.html#a3c4040805bc365d66731218fea670871", null ]
];