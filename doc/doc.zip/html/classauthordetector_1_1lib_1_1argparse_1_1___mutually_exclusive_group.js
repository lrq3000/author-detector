var classauthordetector_1_1lib_1_1argparse_1_1___mutually_exclusive_group =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___mutually_exclusive_group.html#a23b0db872a274937aa16f6e221c20077", null ],
    [ "required", "classauthordetector_1_1lib_1_1argparse_1_1___mutually_exclusive_group.html#ac7fd671d80659a6b5cb7fa8cde426b3e", null ]
];