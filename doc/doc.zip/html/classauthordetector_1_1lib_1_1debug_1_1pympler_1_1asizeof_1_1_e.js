var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_e =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1_e.html#a1d4d442e8e79a171a51967204721782f", null ]
];