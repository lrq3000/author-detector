var classauthordetector_1_1lib_1_1argparse_1_1___attribute_holder =
[
    [ "__repr__", "classauthordetector_1_1lib_1_1argparse_1_1___attribute_holder.html#a45dfd61a7d938673f129bc2e923dbab6", null ]
];