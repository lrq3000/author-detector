var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1garbagegraph_1_1_garbage_graph =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1garbagegraph_1_1_garbage_graph.html#af18baf0a75e9fbd72b2be066fe9a9196", null ],
    [ "print_stats", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1garbagegraph_1_1_garbage_graph.html#ae8e80a518c581144cf341a04cd76561f", null ]
];