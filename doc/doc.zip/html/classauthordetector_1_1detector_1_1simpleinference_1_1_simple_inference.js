var classauthordetector_1_1detector_1_1simpleinference_1_1_simple_inference =
[
    [ "__init__", "classauthordetector_1_1detector_1_1simpleinference_1_1_simple_inference.html#a92278b1c5141cec316ebd6d174123075", null ],
    [ "detect", "classauthordetector_1_1detector_1_1simpleinference_1_1_simple_inference.html#a3300527c04f7348f5aa3372903ce40c0", null ]
];