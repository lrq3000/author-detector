var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_interactive_browser =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_interactive_browser.html#ab38618b7579038dad2a2c9dc3e73a8f5", null ],
    [ "main", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1refbrowser_1_1_interactive_browser.html#a4b78a55d981d2b3cf60c6de94ae52425", null ]
];