var classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer.html#ab18432900f0388ad56879623fc1ab005", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer.html#a3ae21b67fa84bf86acc39a0a9be1e0ed", null ],
    [ "atexit", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer.html#a370667ef08a6f1c07e2d8b4a16ceb690", null ],
    [ "fn", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer.html#a06c7cd0c8f15320aade30a3c7a06ca30", null ],
    [ "immediate", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer.html#a27ed58065f178757daa1ed1f94182700", null ],
    [ "ncalls", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer.html#a7f578f559caae19a3f9ad64060c168af", null ],
    [ "timer", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer.html#a8d1ab2c45588a6be97770248396543b8", null ],
    [ "totaltime", "classauthordetector_1_1lib_1_1debug_1_1profilehooks_1_1_func_timer.html#ae9316af48932d662deebbc2524d2b2f2", null ]
];