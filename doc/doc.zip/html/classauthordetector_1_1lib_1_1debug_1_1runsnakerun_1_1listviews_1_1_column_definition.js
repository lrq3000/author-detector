var classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1listviews_1_1_column_definition =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1listviews_1_1_column_definition.html#a870b6433f2072a4c5e1c810d459236d2", null ],
    [ "get", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1listviews_1_1_column_definition.html#ac9bf11514c25dd1955dcbe3c4c750c14", null ]
];