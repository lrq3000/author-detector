var classauthordetector_1_1featuresextractor_1_1treetagger_1_1_tree_tagger =
[
    [ "__init__", "classauthordetector_1_1featuresextractor_1_1treetagger_1_1_tree_tagger.html#ae636aea5750e2c096f70b8ce04167831", null ],
    [ "extract", "classauthordetector_1_1featuresextractor_1_1treetagger_1_1_tree_tagger.html#af4b50f9658c6d481518ee4cbc7acc0c8", null ]
];