var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___named_ref =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___named_ref.html#ab6b1269c16741fa31a1b6aee6242ddbf", null ],
    [ "name", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___named_ref.html#ab216706d88a1cfb7f40cd91bfa01a8a6", null ],
    [ "ref", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___named_ref.html#a9aefe6c4d61f6d4e13a5ae88968906e7", null ]
];