var classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action =
[
    [ "_ChoicesPseudoAction", "classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action_1_1___choices_pseudo_action.html", "classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action_1_1___choices_pseudo_action" ],
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action.html#abbf6a01cd4d76a2ccc777adf194980da", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action.html#a17ca9458c1f68c403712de1a98eda627", null ],
    [ "add_parser", "classauthordetector_1_1lib_1_1argparse_1_1___sub_parsers_action.html#ae1480d1fe2af783cd5e5a24881a395ee", null ]
];