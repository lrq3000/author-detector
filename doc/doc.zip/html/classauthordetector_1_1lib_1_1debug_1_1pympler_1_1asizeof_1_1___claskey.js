var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___claskey =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___claskey.html#abd43b9a4db23b274c37a12bb2742c4b4", null ],
    [ "__str__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1asizeof_1_1___claskey.html#a768148671916ea0f9c219af5ecdafb53", null ]
];