var classauthordetector_1_1lib_1_1argparse_1_1_namespace =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1_namespace.html#ab8e520ae012e119d0bdc05c48b0fab5c", null ],
    [ "__contains__", "classauthordetector_1_1lib_1_1argparse_1_1_namespace.html#aa10e0375268cfd2d1160191fff7da2d9", null ],
    [ "__eq__", "classauthordetector_1_1lib_1_1argparse_1_1_namespace.html#a6341fa193a94115f047bfd09d21fa412", null ],
    [ "__ne__", "classauthordetector_1_1lib_1_1argparse_1_1_namespace.html#a04e8ecc4db3887bc36b5f5dc0b921b18", null ]
];