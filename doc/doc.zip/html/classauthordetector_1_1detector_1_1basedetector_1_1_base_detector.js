var classauthordetector_1_1detector_1_1basedetector_1_1_base_detector =
[
    [ "__init__", "classauthordetector_1_1detector_1_1basedetector_1_1_base_detector.html#ac8bf593b04093c2b86977aecbfceeee8", null ],
    [ "detect", "classauthordetector_1_1detector_1_1basedetector_1_1_base_detector.html#a1bf780ac18d2b8547b7b04c84064d52c", null ]
];