var classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section.html#a92252bd8f61f35704c05198d97e726bf", null ],
    [ "format_help", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section.html#af4bcf2148bf4cd854c3d9690b3d550e0", null ],
    [ "formatter", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section.html#a6331587d2c24bf43ed103c732190bbcb", null ],
    [ "heading", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section.html#a1bff32baac43f41bdd7bd564a0c49024", null ],
    [ "items", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section.html#ae8d045b25e360b3ffcee319b643cbd71", null ],
    [ "parent", "classauthordetector_1_1lib_1_1argparse_1_1_help_formatter_1_1___section.html#af391a99f2966afe35a659cb50fb8d2a6", null ]
];