var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_error =
[
    [ "__init__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_error.html#aa66358ef98985b45ad925e65d1f67942", null ],
    [ "__repr__", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_error.html#af982a5be2162c83bcf2be0890e731235", null ],
    [ "exception", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_error.html#a3c880736844cce50fdcb5f07dd474549", null ],
    [ "traceback", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1util_1_1bottle3_1_1_h_t_t_p_error.html#a1d75925d1610709c2b9339231ba243c2", null ]
];