var classauthordetector_1_1lib_1_1argparse_1_1___store_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___store_action.html#ade69574ffaee88b61f55885a6c41877c", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1argparse_1_1___store_action.html#a754ecb1f1ce9eeb4163ede860545e51b", null ]
];