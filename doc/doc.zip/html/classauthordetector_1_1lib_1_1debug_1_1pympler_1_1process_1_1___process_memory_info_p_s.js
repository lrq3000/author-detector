var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_p_s =
[
    [ "update", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_p_s.html#a6380c7cc4740699fdb5be27d484356a4", null ],
    [ "rss", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_p_s.html#aefb9e4745f9f1117eb1b1364250682bf", null ],
    [ "vsz", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_p_s.html#a683de2b6702c4bacddb851950125e44a", null ]
];