var classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_win32 =
[
    [ "update", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_win32.html#ad3531a07c2c4cb6fc97f9262cd772e7b", null ],
    [ "pagefaults", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_win32.html#aeb4513421d0798704f89293f3f29267b", null ],
    [ "rss", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_win32.html#a63d9fa46a2fab9c183dd9de1d6443c11", null ],
    [ "vsz", "classauthordetector_1_1lib_1_1debug_1_1pympler_1_1process_1_1___process_memory_info_win32.html#a21c80d0eedd33b4715242ba37768eb85", null ]
];