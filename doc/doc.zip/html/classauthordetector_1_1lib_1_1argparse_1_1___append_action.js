var classauthordetector_1_1lib_1_1argparse_1_1___append_action =
[
    [ "__init__", "classauthordetector_1_1lib_1_1argparse_1_1___append_action.html#ace3165df58b6e1f8b8fc1cfe934e69ae", null ],
    [ "__call__", "classauthordetector_1_1lib_1_1argparse_1_1___append_action.html#a3a256ccb2668105491ff3cc4fd408b3a", null ]
];