var classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_test_app =
[
    [ "get_model", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_test_app.html#a5c888707448036bff3c745199ffebd68", null ],
    [ "OnInit", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_test_app.html#a55581244da0894d0b8a90f74320fb99e", null ],
    [ "OnSquareSelected", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_test_app.html#afa3d52bfdcdfdf409a2f1a53a5f95a6c", null ],
    [ "frame", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_test_app.html#abbdf4cfc591350cee42dc581435238ca", null ],
    [ "sq", "classauthordetector_1_1lib_1_1debug_1_1runsnakerun_1_1meliaeadapter_1_1_test_app.html#a572b6e245c85bc4f068121f60c061c17", null ]
];